Instructions:
1. Create a folder with the name Test, preferably on the machine's c:. If you wish to create it with a different name or on another unit, please change the App.config file.
2. Below is an example of how to perform the conversion:
https://s3.amazonaws.com/uux-itaas-static/minha-cdn-logs/input-01.txt C:\Test\text.txt